package com.itheima.mall.dao;

import com.itheima.mall.pojo.Item;

public interface OrderItemDao {

    public void add(Item item);
}
