package com.itheima.mall.dao;

import com.itheima.mall.pojo.Category;

import java.util.List;

public interface CategoryDao {

    public List<Category> findAll();

}
